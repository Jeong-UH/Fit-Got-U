var http = require('http');
var querystring = require('querystring');
var mysql = require('mysql');
var FCM = require('fcm-node');
var serverKey = 'AAAACSUJ3E0:APA91bHa1QknU0jMh4u6gK1W-2UuMPgL98P82ooA4mHR-JonpZ2CVnSS6gI9-OuO5edz5n2tnxDMYSCL1QIJaYP1vdeGxGY5Nf6kkr-HINuTWVZ3ROhGGAbQ2G64jn9ytuPhQ6z8IyKO';
var fcm = new FCM(serverKey);

var connection = mysql.createConnection({
	host: 'localhost',
	post: 3306,
	user: 'jelly',
	password: 'Pa$$w0rd1234',
	database: 'jellyDB'
});

var server = http.createServer().listen(4000);

server.on('request', function (req, res) {
    if (req.method == 'POST') {
        var body = '';
    }

    req.on('data', function (data) {
        body += data;
    });

    req.on('end', function () {
        var post = querystring.parse(body);
        res.writeHead(200, {'Content-Type': 'text/plain'});
        res.end('ok\n');

		var sql = 'SELECT token FROM fcmtoken where id=?';

		connection.query(sql, [post.targetid], function (err, result) {
			if (err) console.log(err);
			var targettoken = result[0].token;

			var push_data = {
				// 수신대상
				to: targettoken,
				// App이 실행중이지 않을 때 상태바 알림으로 등록할 내용
				notification: {
					title: post.title,
					body: post.content
				},
				// 메시지 중요도
				priority: "high",
				// App 패키지 이름
				restricted_package_name: "com.example",
				// App에게 전달할 데이터
				data: {
					action: post.action
				}
			};
 
			fcm.send(push_data, function(err, response) {
				if (err) {
					console.error('Push메시지 발송에 실패했습니다.');
					console.error(err);
					return;
				}

				console.log('Push메시지가 발송되었습니다.');
				console.log(response);
			});
		});
    });
});

console.log('Listening on port 4000');
