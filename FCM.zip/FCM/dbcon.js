var mysql = require('mysql');

var connection = mysql.createConnection({
	host: 'localhost',
	post: 3306,
	user: 'jelly',
	password: 'Pa$$w0rd1234',
	database: 'jellyDB'
});

module.exports = connection;
